## Packages
zustand | Global state management for language and theme settings
framer-motion | Smooth animations for page transitions and card interactions

## Notes
- Using Shadcn UI sidebar components as requested.
- Images for recipes are loaded dynamically via Unsplash source URLs to simulate a real API response.
- Tailwind dark mode is controlled via the `.dark` class on the `html` element.
