import { useEffect } from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider } from "@/components/ui/sidebar";
import { useAppStore } from "@/store/use-app-store";

// Layout & Components
import { AppSidebar } from "@/components/layout/app-sidebar";
import { Header } from "@/components/layout/header";

// Pages
import Home from "@/pages/home";
import Favorites from "@/pages/favorites";
import Settings from "@/pages/settings";
import Placeholder from "@/pages/placeholder";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/favorites" component={Favorites} />
      <Route path="/settings" component={Settings} />
      {/* Placeholder pages for sidebar items without specific designs in mockup */}
      <Route path="/payments" component={Placeholder} />
      <Route path="/notifications" component={Placeholder} />
      <Route path="/about" component={Placeholder} />
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function ThemeManager() {
  const { theme } = useAppStore();
  
  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [theme]);

  return null;
}

function App() {
  const style = {
    "--sidebar-width": "18rem",
    "--sidebar-width-icon": "4rem",
  } as React.CSSProperties;

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <ThemeManager />
        <SidebarProvider style={style}>
          <div className="flex min-h-screen w-full bg-background selection:bg-primary/30">
            <AppSidebar />
            
            <div className="flex flex-col flex-1 min-w-0 overflow-hidden relative">
              {/* Decorative background glow elements */}
              <div className="absolute top-[-10%] right-[-5%] w-[40%] h-[40%] bg-primary/10 rounded-full blur-[120px] pointer-events-none" />
              <div className="absolute bottom-[-10%] left-[-10%] w-[30%] h-[30%] bg-blue-500/10 rounded-full blur-[100px] pointer-events-none" />
              
              <Header />
              
              <main className="flex-1 overflow-y-auto relative z-10 scroll-smooth">
                <div className="mx-auto max-w-7xl w-full">
                  <Router />
                </div>
              </main>
            </div>
          </div>
        </SidebarProvider>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
