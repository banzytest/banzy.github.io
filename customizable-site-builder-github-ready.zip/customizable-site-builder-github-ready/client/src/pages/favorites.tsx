import { useRecipes } from "@/hooks/use-recipes";
import { RecipeCard } from "@/components/recipe/recipe-card";
import { useTranslation } from "@/lib/i18n";
import { Loader2, HeartCrack } from "lucide-react";
import { motion } from "framer-motion";

export default function Favorites() {
  const { data: recipes, isLoading } = useRecipes();
  const t = useTranslation();

  const favoriteRecipes = recipes?.filter((r) => r.isFavorite) || [];

  if (isLoading) {
    return (
      <div className="flex-1 flex items-center justify-center min-h-[50vh]">
        <Loader2 className="h-10 w-10 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="px-4 sm:px-6 pb-20">
      <motion.div 
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8 mt-4"
      >
        <h2 className="text-3xl font-display font-bold">{t.menu_favorites}</h2>
      </motion.div>

      {favoriteRecipes.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {favoriteRecipes.map((recipe, index) => (
            <RecipeCard key={recipe.id} recipe={recipe} index={index} />
          ))}
        </div>
      ) : (
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="flex flex-col items-center justify-center py-32 text-center"
        >
          <div className="w-24 h-24 bg-white/5 rounded-full flex items-center justify-center mb-6 shadow-inner border border-white/5">
            <HeartCrack className="w-10 h-10 text-muted-foreground" />
          </div>
          <h3 className="text-2xl font-bold text-foreground mb-3">{t.empty_favorites}</h3>
          <p className="text-muted-foreground max-w-sm">
            {t.empty_favorites_desc}
          </p>
        </motion.div>
      )}
    </div>
  );
}
