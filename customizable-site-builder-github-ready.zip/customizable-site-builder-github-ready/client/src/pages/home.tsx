import { useRecipes } from "@/hooks/use-recipes";
import { RecipeCard } from "@/components/recipe/recipe-card";
import { useTranslation } from "@/lib/i18n";
import { Loader2, ChefHat, Plus, X, Search, Trash2, Check, Filter, Dices, ShoppingCart, Sun, Moon } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useAppStore } from "@/store/use-app-store";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useState, useMemo, useEffect } from "react";
import { Dialog, DialogContent, DialogTrigger, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function Home() {
  const { data: recipes, isLoading, error } = useRecipes();
  const t = useTranslation();
  const { 
    searchQuery, 
    setSearchQuery,
    selectedCategory, 
    setSelectedCategory,
    userIngredients,
    addUserIngredient,
    removeUserIngredient,
    clearUserIngredients,
    shoppingList,
    removeFromShoppingList,
    clearShoppingList,
    theme,
    setTheme
  } = useAppStore();

  const [inputValue, setInputValue] = useState("");
  const [maxTime, setMaxTime] = useState<number | null>(null);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
  }, [theme]);

  const popularIngredients = [
    { id: 'eggs', label: t.ingredient_eggs, value: 'яйца' },
    { id: 'chicken', label: t.ingredient_chicken, value: 'курица' },
    { id: 'cheese', label: t.ingredient_cheese, value: 'сыр' },
    { id: 'rice', label: t.ingredient_rice, value: 'рис' },
    { id: 'potato', label: t.ingredient_potato, value: 'картофель' },
  ];

  const handleAddIngredient = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (inputValue.trim()) {
      addUserIngredient(inputValue.trim().toLowerCase());
      setInputValue("");
    }
  };

  const categories = [
    { id: 'all', label: t.cat_all },
    { id: 'breakfast', label: t.cat_breakfast },
    { id: 'lunch', label: t.cat_lunch },
    { id: 'dinner', label: t.cat_dinner },
    { id: 'desserts', label: t.cat_desserts },
    { id: 'snack', label: t.cat_snack },
  ];

  const timeFilters = [
    { id: 'all', label: t.time_filter_all, value: null },
    { id: '15', label: t.time_filter_15, value: 15 },
    { id: '30', label: t.time_filter_30, value: 30 },
    { id: '60', label: t.time_filter_60, value: 60 },
  ];

  const filteredRecipes = useMemo(() => {
    if (!recipes) return [];

    const query = searchQuery.toLowerCase().trim();

    let filtered = recipes.filter(recipe => {
      const matchesCategory = selectedCategory === 'all' || recipe.category === selectedCategory;
      const matchesTime = maxTime === null || recipe.timeMinutes <= maxTime;
      
      if (!matchesCategory || !matchesTime) return false;

      if (!query) return true;

      const titleMatch = recipe.title.toLowerCase().includes(query);
      const descMatch = recipe.description.toLowerCase().includes(query);
      const ingredients = recipe.ingredients?.toLowerCase() || "";
      const ingMatch = ingredients.includes(query);

      return titleMatch || descMatch || ingMatch;
    });

    return filtered.map(recipe => {
      const recipeIngredients = recipe.ingredients?.toLowerCase().split('\n').map(line => line.replace('• ', '').trim()).filter(Boolean) || [];
      const userHasIngs = userIngredients.length > 0;
      
      const matchedIngredients = recipeIngredients.filter(reqIng => 
        userIngredients.some(userIng => reqIng.includes(userIng.toLowerCase()))
      );
      
      const missingInUser = recipeIngredients.filter(reqIng => 
        !userIngredients.some(userIng => reqIng.includes(userIng.toLowerCase()))
      );

      return {
        ...recipe,
        missingCount: missingInUser.length,
        missingIngredients: missingInUser,
        matchCount: matchedIngredients.length,
        totalCount: recipeIngredients.length,
        hasUserIngs: userHasIngs,
        isMatch: userIngredients.length === 0 || matchedIngredients.length > 0
      };
    })
    .filter(recipe => recipe.isMatch)
    .sort((a, b) => {
      if (a.hasUserIngs && b.hasUserIngs) {
        return b.matchCount - a.matchCount;
      }
      return 0;
    });
  }, [recipes, searchQuery, selectedCategory, userIngredients, maxTime]);

  const randomRecipe = useMemo(() => {
    if (!recipes || recipes.length === 0) return null;
    return recipes[Math.floor(Math.random() * recipes.length)];
  }, [recipes]);

  if (isLoading) {
    return (
      <div className="flex-1 flex items-center justify-center min-h-[50vh]">
        <Loader2 className="h-10 w-10 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="px-4 sm:px-6 pb-20 max-w-7xl mx-auto">
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-12 mt-8 text-center"
      >
        <div className="flex justify-center items-center mb-6 gap-4">
          <Button
            variant="outline"
            size="icon"
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            className="rounded-2xl border-white/10 bg-card h-12 w-12 shadow-md"
          >
            {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </Button>

          <div className="relative w-full max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.search_placeholder}
              className="pl-10 h-12 rounded-2xl bg-card border-white/10 focus:ring-primary/20 shadow-inner"
            />
          </div>

          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline" className="h-12 rounded-2xl border-white/10 bg-card hover:bg-primary/10 hover:text-primary transition-all shadow-md group">
                <Dices className="w-5 h-5 mr-2 group-hover:rotate-12 transition-transform" />
                {t.random_recipe}
              </Button>
            </DialogTrigger>
            {randomRecipe && (
              <DialogContent className="max-w-md p-0 overflow-hidden rounded-3xl border-none">
                <RecipeCard recipe={randomRecipe} index={0} />
              </DialogContent>
            )}
          </Dialog>

          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline" className="h-12 w-12 rounded-2xl border-white/10 bg-card relative shadow-md">
                <ShoppingCart className="w-5 h-5" />
                {shoppingList.length > 0 && (
                  <span className="absolute -top-1 -right-1 bg-primary text-primary-foreground text-[10px] font-bold h-5 w-5 flex items-center justify-center rounded-full border-2 border-background">
                    {shoppingList.length}
                  </span>
                )}
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md bg-card border-white/10 rounded-3xl">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <ShoppingCart className="w-5 h-5 text-primary" />
                  {t.menu_shopping_list}
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-2 custom-scrollbar">
                {shoppingList.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">{t.shopping_list_empty}</p>
                ) : (
                  <div className="space-y-2">
                    {shoppingList.map((item, i) => (
                      <div key={i} className="flex items-center justify-between p-3 bg-white/5 rounded-xl border border-white/5 group">
                        <span className="text-sm">{item}</span>
                        <X 
                          className="w-4 h-4 text-muted-foreground cursor-pointer hover:text-destructive transition-colors opacity-0 group-hover:opacity-100" 
                          onClick={() => removeFromShoppingList(item)}
                        />
                      </div>
                    ))}
                    <Button 
                      variant="ghost" 
                      className="w-full text-destructive hover:bg-destructive/10 rounded-xl mt-4"
                      onClick={clearShoppingList}
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      {t.clear_all}
                    </Button>
                  </div>
                )}
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <h2 className="text-4xl md:text-5xl font-display font-bold mb-4 text-gradient">{t.ingredients_search_title}</h2>
        <div className="max-w-2xl mx-auto">
          <form onSubmit={handleAddIngredient} className="flex gap-2 mb-4">
            <div className="relative flex-1">
              <Plus className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input 
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder={t.ingredients_search_placeholder}
                className="pl-10 h-12 rounded-2xl bg-card border-white/10 focus:ring-primary/20"
              />
            </div>
            <Button type="submit" className="h-12 px-6 rounded-2xl bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg shadow-primary/20 transition-all active:scale-95">
              {t.add_ingredient}
            </Button>
          </form>

          <div className="flex flex-wrap gap-2 mb-4 min-h-[40px]">
            <AnimatePresence>
              {userIngredients.map((ing) => (
                <motion.div
                  key={ing}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                >
                  <Badge className="bg-primary/15 text-primary border-primary/20 px-3 py-1.5 rounded-xl flex items-center gap-2 group transition-all hover:bg-primary/20">
                    {ing}
                    <X 
                      className="w-3 h-3 cursor-pointer hover:text-destructive transition-colors" 
                      onClick={() => removeUserIngredient(ing)}
                    />
                  </Badge>
                </motion.div>
              ))}
            </AnimatePresence>
            {userIngredients.length > 0 && (
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={clearUserIngredients}
                className="text-muted-foreground hover:text-destructive rounded-xl h-9"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                {t.clear_all}
              </Button>
            )}
          </div>

          <div className="flex items-center gap-3 text-sm text-muted-foreground mb-8">
            <span>{t.popular_ingredients}</span>
            <div className="flex flex-wrap gap-2">
              {popularIngredients.map(item => (
                <button
                  key={item.id}
                  onClick={() => addUserIngredient(item.value)}
                  className="px-3 py-1 rounded-full bg-white/5 border border-white/5 hover:bg-white/10 hover:border-primary/30 transition-all text-xs"
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
          
          <div className="flex flex-wrap justify-center gap-2 mb-4 border-t border-white/5 pt-8">
            {categories.map((cat) => (
              <Button
                key={cat.id}
                variant={selectedCategory === cat.id ? "default" : "outline"}
                className={`rounded-full px-6 transition-all ${
                  selectedCategory === cat.id 
                    ? "bg-primary text-primary-foreground shadow-lg shadow-primary/20 scale-105" 
                    : "hover:bg-primary/10 hover:text-primary border-white/10"
                }`}
                onClick={() => setSelectedCategory(cat.id)}
              >
                {cat.label}
              </Button>
            ))}
          </div>

          <div className="flex flex-wrap justify-center gap-2">
            {timeFilters.map((filter) => (
              <button
                key={filter.id}
                onClick={() => setMaxTime(filter.value)}
                className={`text-xs px-3 py-1.5 rounded-xl transition-all border ${
                  maxTime === filter.value 
                    ? "bg-primary/20 border-primary text-primary font-bold" 
                    : "bg-card border-white/5 text-muted-foreground hover:border-white/20"
                }`}
              >
                {filter.label}
              </button>
            ))}
          </div>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        <AnimatePresence mode="popLayout">
          {filteredRecipes.length > 0 ? (
            filteredRecipes.map((recipe, index) => (
              <motion.div 
                key={recipe.id} 
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="relative flex flex-col"
              >
                {(recipe as any).missingCount === 0 && userIngredients.length > 0 && (
                  <div className="absolute -top-2 -right-2 z-30 bg-green-500 text-white p-1.5 rounded-full shadow-lg border-2 border-background animate-bounce">
                    <Check className="w-4 h-4" />
                  </div>
                )}
                <RecipeCard recipe={recipe} index={index} />
                {userIngredients.length > 0 && (
                  <div className="mt-3 space-y-2">
                    <div className="px-4 py-2 bg-primary/10 border border-primary/20 rounded-2xl text-[11px] text-primary font-bold">
                      {t.ingredients_stat.replace('{{count}}', (recipe as any).matchCount).replace('{{total}}', (recipe as any).totalCount)}
                    </div>
                    {(recipe as any).missingIngredients?.length > 0 && (
                      <div className="px-4 py-2 bg-destructive/10 border border-destructive/20 rounded-2xl text-[10px] text-destructive font-bold uppercase tracking-wider">
                        {t.missing_ingredients} {(recipe as any).missingIngredients.slice(0, 3).join(", ")}
                      </div>
                    )}
                  </div>
                )}
              </motion.div>
            ))
          ) : (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="col-span-full text-center py-20 bg-card/30 rounded-[2.5rem] border border-white/5"
            >
              <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <ChefHat className="w-10 h-10 text-primary" />
              </div>
              <h3 className="text-2xl font-bold mb-2">{t.no_recipes_found || t.no_results_title}</h3>
              <p className="text-muted-foreground max-w-sm mx-auto px-4">
                {t.no_results_desc}
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
