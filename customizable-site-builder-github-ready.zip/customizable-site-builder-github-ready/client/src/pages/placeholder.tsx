import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Settings, CreditCard, Bell, Info } from "lucide-react";
import { useTranslation } from "@/lib/i18n";
import { motion } from "framer-motion";

export default function Placeholder() {
  const [location] = useLocation();
  const t = useTranslation();

  let title = "Раздел";
  let icon = <Info className="w-12 h-12 text-muted-foreground" />;

  if (location.includes("payments")) {
    title = t.menu_payments;
    icon = <CreditCard className="w-12 h-12 text-primary" />;
  } else if (location.includes("notifications")) {
    title = t.menu_notifications;
    icon = <Bell className="w-12 h-12 text-primary" />;
  } else if (location.includes("about")) {
    title = t.menu_about;
  }

  return (
    <div className="px-4 sm:px-6 h-[80vh] flex flex-col items-center justify-center">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.3 }}
      >
        <Card className="bg-card/30 backdrop-blur-xl border-white/5 p-12 flex flex-col items-center text-center max-w-md w-full shadow-2xl">
          <div className="w-24 h-24 bg-white/5 rounded-3xl flex items-center justify-center mb-6 shadow-inner border border-white/10">
            {icon}
          </div>
          <h2 className="text-3xl font-display font-bold mb-4">{title}</h2>
          <p className="text-muted-foreground leading-relaxed">
            Этот раздел находится в стадии активной разработки. Возвращайтесь позже, чтобы увидеть новые возможности.
          </p>
        </Card>
      </motion.div>
    </div>
  );
}
