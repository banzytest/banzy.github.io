import { useAppStore } from "@/store/use-app-store";
import { useTranslation } from "@/lib/i18n";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { CheckCircle2, Moon, Sun, Languages } from "lucide-react";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";

export default function Settings() {
  const { language, theme, setLanguage, setTheme } = useAppStore();
  const t = useTranslation();
  const { toast } = useToast();

  const handleSave = () => {
    toast({
      description: t.save_success,
      duration: 2000,
    });
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 pb-20">
      <motion.div 
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8 mt-4"
      >
        <h2 className="text-3xl font-display font-bold">{t.settings_title}</h2>
      </motion.div>

      <div className="space-y-6">
        {/* Theme Settings */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <Card className="bg-card/50 backdrop-blur-sm border-white/10 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Moon className="w-5 h-5 text-primary" />
                {t.theme}
              </CardTitle>
              <CardDescription>
                {t.settings_theme_desc}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <RadioGroup 
                value={theme} 
                onValueChange={(val: 'dark' | 'light') => setTheme(val)}
                className="grid grid-cols-2 gap-4"
              >
                <div>
                  <RadioGroupItem value="light" id="theme-light" className="peer sr-only" />
                  <Label
                    htmlFor="theme-light"
                    className="flex flex-col items-center justify-between rounded-xl border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/10 [&:has([data-state=checked])]:border-primary cursor-pointer transition-all"
                  >
                    <Sun className="mb-3 h-8 w-8" />
                    {t.theme_light}
                  </Label>
                </div>
                <div>
                  <RadioGroupItem value="dark" id="theme-dark" className="peer sr-only" />
                  <Label
                    htmlFor="theme-dark"
                    className="flex flex-col items-center justify-between rounded-xl border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/10 [&:has([data-state=checked])]:border-primary cursor-pointer transition-all"
                  >
                    <Moon className="mb-3 h-8 w-8" />
                    {t.theme_dark}
                  </Label>
                </div>
              </RadioGroup>
            </CardContent>
          </Card>
        </motion.div>

        {/* Language Settings */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <Card className="bg-card/50 backdrop-blur-sm border-white/10 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Languages className="w-5 h-5 text-primary" />
                {t.language}
              </CardTitle>
              <CardDescription>
                {t.settings_lang_desc}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <RadioGroup 
                value={language} 
                onValueChange={(val: 'ru' | 'en' | 'de' | 'uk' | 'fr' | 'es') => setLanguage(val)}
                className="grid grid-cols-3 gap-4"
              >
                <div>
                  <RadioGroupItem value="ru" id="lang-ru" className="peer sr-only" />
                  <Label
                    htmlFor="lang-ru"
                    className="flex flex-col items-center justify-center rounded-xl border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/10 cursor-pointer transition-all h-full"
                  >
                    <span className="font-medium">RU</span>
                    {language === 'ru' && <CheckCircle2 className="w-4 h-4 text-primary mt-1" />}
                  </Label>
                </div>
                <div>
                  <RadioGroupItem value="en" id="lang-en" className="peer sr-only" />
                  <Label
                    htmlFor="lang-en"
                    className="flex flex-col items-center justify-center rounded-xl border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/10 cursor-pointer transition-all h-full"
                  >
                    <span className="font-medium">EN</span>
                    {language === 'en' && <CheckCircle2 className="w-4 h-4 text-primary mt-1" />}
                  </Label>
                </div>
                <div>
                  <RadioGroupItem value="de" id="lang-de" className="peer sr-only" />
                  <Label
                    htmlFor="lang-de"
                    className="flex flex-col items-center justify-center rounded-xl border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/10 cursor-pointer transition-all h-full"
                  >
                    <span className="font-medium">DE</span>
                    {language === 'de' && <CheckCircle2 className="w-4 h-4 text-primary mt-1" />}
                  </Label>
                </div>
                <div>
                  <RadioGroupItem value="uk" id="lang-uk" className="peer sr-only" />
                  <Label
                    htmlFor="lang-uk"
                    className="flex flex-col items-center justify-center rounded-xl border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/10 cursor-pointer transition-all h-full"
                  >
                    <span className="font-medium">UK</span>
                    {language === 'uk' && <CheckCircle2 className="w-4 h-4 text-primary mt-1" />}
                  </Label>
                </div>
                <div>
                  <RadioGroupItem value="fr" id="lang-fr" className="peer sr-only" />
                  <Label
                    htmlFor="lang-fr"
                    className="flex flex-col items-center justify-center rounded-xl border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/10 cursor-pointer transition-all h-full"
                  >
                    <span className="font-medium">FR</span>
                    {language === 'fr' && <CheckCircle2 className="w-4 h-4 text-primary mt-1" />}
                  </Label>
                </div>
                <div>
                  <RadioGroupItem value="es" id="lang-es" className="peer sr-only" />
                  <Label
                    htmlFor="lang-es"
                    className="flex flex-col items-center justify-center rounded-xl border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/10 cursor-pointer transition-all h-full"
                  >
                    <span className="font-medium">ES</span>
                    {language === 'es' && <CheckCircle2 className="w-4 h-4 text-primary mt-1" />}
                  </Label>
                </div>
              </RadioGroup>
            </CardContent>
          </Card>
        </motion.div>

        {/* Submit Recipe */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <Card className="bg-card/50 backdrop-blur-sm border-white/10 shadow-lg">
            <CardHeader>
              <CardTitle>{t.submit_recipe}</CardTitle>
              <CardDescription>{t.submit_recipe_desc}</CardDescription>
            </CardHeader>
            <CardContent>
              <form className="space-y-4" onSubmit={(e) => {
                e.preventDefault();
                toast({ description: t.submit_recipe_success });
              }}>
                <div className="space-y-2">
                  <Label>{t.recipe_name}</Label>
                  <Input placeholder={t.name_placeholder} />
                </div>
                <div className="space-y-2">
                  <Label>{t.recipe_desc}</Label>
                  <Input placeholder={t.desc_placeholder} />
                </div>
                <div className="space-y-2">
                  <Label>{t.ingredients}</Label>
                  <Input placeholder={t.ing_placeholder} />
                </div>
                <div className="space-y-2">
                  <Label>{t.instructions}</Label>
                  <Input placeholder={t.instr_placeholder} />
                </div>
                <Button type="submit" className="w-full">{t.submit_btn}</Button>
              </form>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0 }} 
          animate={{ opacity: 1 }} 
          transition={{ delay: 0.4 }}
          className="flex justify-end pt-4"
        >
          <Button 
            onClick={handleSave}
            className="rounded-xl px-8 h-12 text-base font-semibold bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg shadow-primary/25"
          >
            {t.save}
          </Button>
        </motion.div>
      </div>
    </div>
  );
}
