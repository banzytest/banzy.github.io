import { create } from 'zustand';
import { persist } from 'zustand/middleware';

type Language = 'ru' | 'en' | 'de' | 'uk' | 'fr' | 'es';
type Theme = 'dark' | 'light';

interface AppState {
  language: Language;
  theme: Theme;
  searchQuery: string;
  selectedCategory: string;
  userIngredients: string[];
  shoppingList: string[];
  setLanguage: (lang: Language) => void;
  setTheme: (theme: Theme) => void;
  setSearchQuery: (query: string) => void;
  setSelectedCategory: (category: string) => void;
  setUserIngredients: (ingredients: string[]) => void;
  addUserIngredient: (ingredient: string) => void;
  removeUserIngredient: (ingredient: string) => void;
  clearUserIngredients: () => void;
  addToShoppingList: (ingredients: string) => void;
  removeFromShoppingList: (ingredient: string) => void;
  clearShoppingList: () => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      language: 'ru',
      theme: 'dark',
      searchQuery: '',
      selectedCategory: 'all',
      userIngredients: [],
      shoppingList: [],
      setLanguage: (language) => set({ language }),
      setTheme: (theme) => set({ theme }),
      setSearchQuery: (searchQuery) => set({ searchQuery }),
      setSelectedCategory: (selectedCategory) => set({ selectedCategory }),
      setUserIngredients: (userIngredients) => set({ userIngredients }),
      addUserIngredient: (ingredient) => set((state) => ({
        userIngredients: state.userIngredients.includes(ingredient.toLowerCase())
          ? state.userIngredients
          : [...state.userIngredients, ingredient.toLowerCase()]
      })),
      removeUserIngredient: (ingredient) => set((state) => ({
        userIngredients: state.userIngredients.filter(i => i !== ingredient)
      })),
      clearUserIngredients: () => set({ userIngredients: [] }),
      addToShoppingList: (ingredientsStr) => set((state) => {
        const newIngs = ingredientsStr.split('\n').map(i => i.replace('• ', '').trim()).filter(Boolean);
        const updatedList = Array.from(new Set([...state.shoppingList, ...newIngs]));
        return { shoppingList: updatedList };
      }),
      removeFromShoppingList: (ingredient) => set((state) => ({
        shoppingList: state.shoppingList.filter(i => i !== ingredient)
      })),
      clearShoppingList: () => set({ shoppingList: [] }),
    }),
    {
      name: 'app-storage',
    }
  )
);
