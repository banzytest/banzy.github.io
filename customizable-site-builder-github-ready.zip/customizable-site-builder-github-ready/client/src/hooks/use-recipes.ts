import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type RecipeResponse, type RecipesListResponse } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";
import { useTranslation } from "@/lib/i18n";

export function useRecipes() {
  return useQuery({
    queryKey: [api.recipes.list.path],
    queryFn: async () => {
      const res = await fetch(api.recipes.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch recipes");
      return api.recipes.list.responses[200].parse(await res.json());
    },
  });
}

export function useRecipe(id: number) {
  return useQuery({
    queryKey: [api.recipes.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.recipes.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch recipe");
      return api.recipes.get.responses[200].parse(await res.json());
    },
    enabled: !!id,
  });
}

export function useToggleFavorite() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const t = useTranslation();

  return useMutation({
    mutationFn: async ({ id, isFavorite }: { id: number; isFavorite: boolean }) => {
      const url = buildUrl(api.recipes.toggleFavorite.path, { id });
      const validated = api.recipes.toggleFavorite.input.parse({ isFavorite });
      
      const res = await fetch(url, {
        method: api.recipes.toggleFavorite.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      
      if (!res.ok) throw new Error("Failed to toggle favorite");
      return api.recipes.toggleFavorite.responses[200].parse(await res.json());
    },
    onMutate: async ({ id, isFavorite }) => {
      // Optimistic update
      await queryClient.cancelQueries({ queryKey: [api.recipes.list.path] });
      const previousRecipes = queryClient.getQueryData<RecipesListResponse>([api.recipes.list.path]);
      
      if (previousRecipes) {
        queryClient.setQueryData<RecipesListResponse>(
          [api.recipes.list.path],
          previousRecipes.map(r => r.id === id ? { ...r, isFavorite } : r)
        );
      }
      return { previousRecipes };
    },
    onError: (err, newRecipe, context) => {
      // Rollback on error
      if (context?.previousRecipes) {
        queryClient.setQueryData([api.recipes.list.path], context.previousRecipes);
      }
      toast({
        title: "Error",
        description: err.message,
        variant: "destructive",
      });
    },
    onSuccess: (data) => {
      // Show success toast
      toast({
        description: data.isFavorite ? t.added_to_favorites : t.removed_from_favorites,
        duration: 2000,
      });
      queryClient.invalidateQueries({ queryKey: [api.recipes.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.recipes.get.path, data.id] });
    },
  });
}
