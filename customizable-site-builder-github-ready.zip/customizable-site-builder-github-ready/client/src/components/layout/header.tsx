import { Search, Camera } from "lucide-react";
import { SidebarTrigger } from "@/components/ui/sidebar";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useTranslation } from "@/lib/i18n";
import { useToast } from "@/hooks/use-toast";
import { useAppStore } from "@/store/use-app-store";

export function Header() {
  const t = useTranslation();
  const { toast } = useToast();
  const { searchQuery, setSearchQuery } = useAppStore();

  const handleScanClick = () => {
    toast({
      title: "Scanner",
      description: t.scan_not_implemented,
      duration: 3000,
    });
  };

  return (
    <header className="sticky top-0 z-40 w-full glass-panel border-b-0 border-x-0 border-t-0 pb-4 pt-4 px-4 sm:px-6 flex items-center justify-between gap-4">
      <div className="flex items-center gap-4 flex-1">
        <SidebarTrigger className="md:hidden" />
        
        <div className="relative max-w-md w-full hidden sm:block">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder={t.search_placeholder}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-black/20 border-white/10 rounded-2xl h-11 focus-visible:ring-primary/50"
          />
        </div>
      </div>

      <div className="flex items-center gap-4">
        <Button 
          onClick={handleScanClick}
          className="rounded-2xl h-11 px-4 sm:px-6 bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/40 transition-all duration-300 gap-2"
        >
          <Camera size={18} />
          <span className="hidden sm:inline-block font-semibold tracking-wide">{t.scan_ingredients}</span>
        </Button>
      </div>
    </header>
  );
}
