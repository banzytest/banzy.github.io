import { Link, useLocation } from "wouter";
import { 
  ChefHat, 
  Heart, 
  CreditCard, 
  Bell, 
  Settings, 
  Info,
  Camera
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
} from "@/components/ui/sidebar";
import { useTranslation } from "@/lib/i18n";

export function AppSidebar() {
  const [location] = useLocation();
  const t = useTranslation();

  const navItems = [
    { title: t.menu_recipes, url: "/", icon: ChefHat },
    { title: t.menu_favorites, url: "/favorites", icon: Heart },
    { title: t.menu_payments, url: "/payments", icon: CreditCard },
    { title: t.menu_notifications, url: "/notifications", icon: Bell },
    { title: t.menu_settings, url: "/settings", icon: Settings },
    { title: t.menu_about, url: "/about", icon: Info },
  ];

  return (
    <Sidebar className="border-r border-border/50">
      <SidebarHeader className="p-6">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-lg shadow-primary/20">
            <ChefHat size={24} />
          </div>
          <h1 className="text-xl font-bold text-gradient tracking-tight">
            {t.app_name}
          </h1>
        </div>
      </SidebarHeader>
      
      <SidebarContent className="px-3">
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu className="gap-2">
              {navItems.map((item) => {
                const isActive = location === item.url;
                return (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton 
                      asChild 
                      isActive={isActive}
                      tooltip={item.title}
                      className={`
                        h-12 px-4 rounded-xl transition-all duration-200
                        ${isActive 
                          ? 'bg-primary/10 text-primary font-medium hover:bg-primary/15' 
                          : 'text-muted-foreground hover:bg-white/5 hover:text-foreground'
                        }
                      `}
                    >
                      <Link href={item.url} className="flex items-center gap-3 w-full">
                        <item.icon size={20} className={isActive ? "text-primary" : "text-muted-foreground"} />
                        <span className="text-base">{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}
