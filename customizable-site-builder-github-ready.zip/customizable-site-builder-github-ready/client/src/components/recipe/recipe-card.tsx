import { Clock, Flame, Star, Heart, Info, ChevronRight, ShoppingCart } from "lucide-react";
import { type RecipeResponse } from "@shared/routes";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToggleFavorite } from "@/hooks/use-recipes";
import { useTranslation } from "@/lib/i18n";
import { motion } from "framer-motion";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useAppStore } from "@/store/use-app-store";
import { useToast } from "@/hooks/use-toast";

interface RecipeCardProps {
  recipe: RecipeResponse;
  index: number;
}

export function RecipeCard({ recipe, index }: RecipeCardProps) {
  const { mutate: toggleFavorite, isPending } = useToggleFavorite();
  const t = useTranslation();
  const { addToShoppingList } = useAppStore();
  const { toast } = useToast();

  const ingredientList = recipe.ingredients?.split('\n').slice(0, 3).map(i => i.replace('• ', '').trim()) || [];

  const handleAddToList = () => {
    addToShoppingList(recipe.ingredients || "");
    toast({
      title: t.added_to_favorites, // reusing success message or just notification
      description: recipe.title,
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: index * 0.05, ease: "easeOut" }}
    >
      <Card className="group overflow-hidden rounded-[2rem] bg-card border-white/5 shadow-md hover:shadow-2xl hover:shadow-primary/10 hover:border-primary/20 transition-all duration-500 hover:-translate-y-2 h-full flex flex-col">
        <div className="relative aspect-[4/3] overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent z-10" />
          
          <img 
            src={recipe.imageUrl || `https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&q=80`}
            alt={recipe.title}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          />
          
          <Button
            size="icon"
            variant="ghost"
            className={`absolute top-3 right-3 z-20 h-10 w-10 rounded-full backdrop-blur-md transition-all duration-300 ${
              recipe.isFavorite 
                ? 'bg-primary/20 text-primary hover:bg-primary/30' 
                : 'bg-black/30 text-white hover:bg-black/50'
            }`}
            onClick={() => toggleFavorite({ id: recipe.id, isFavorite: !recipe.isFavorite })}
            disabled={isPending}
          >
            <Heart className={recipe.isFavorite ? "fill-current" : ""} size={20} />
          </Button>

          <Button
            size="icon"
            variant="ghost"
            className="absolute top-3 left-3 z-20 h-10 w-10 rounded-full backdrop-blur-md bg-black/30 text-white hover:bg-black/50"
            onClick={handleAddToList}
          >
            <ShoppingCart size={18} />
          </Button>

          <div className="absolute bottom-3 left-3 z-20 flex items-center gap-1.5 bg-black/40 backdrop-blur-md px-2.5 py-1 rounded-full border border-white/10">
            <Star className="fill-primary text-primary" size={14} />
            <span className="text-white text-sm font-medium">{recipe.rating}</span>
          </div>
        </div>

        <CardContent className="p-5 flex-1 flex flex-col">
          <div className="flex items-center gap-2 mb-2">
            <Badge variant="outline" className="text-[10px] uppercase tracking-wider font-bold border-primary/20 text-primary/80 px-2 py-0">
              {t[`cat_${recipe.category}`] || recipe.category}
            </Badge>
          </div>
          <h3 className="font-display text-xl font-bold text-foreground mb-2 line-clamp-1 group-hover:text-primary transition-colors">
            {t[recipe.title] || recipe.title}
          </h3>
          
          <div className="space-y-1 mb-4 flex-1">
            {recipe.ingredients?.split('\n').map((ing, i) => (
              <div key={i} className="flex items-center gap-2 text-muted-foreground text-[11px]">
                <div className="w-1 h-1 rounded-full bg-primary/40" />
                <span className="truncate">{ing.replace('• ', '')}</span>
              </div>
            ))}
          </div>
          
          <div className="flex items-center justify-between mt-auto pt-4 border-t border-white/5">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1 text-muted-foreground/80">
                <Clock size={14} className="text-primary/60" />
                <span className="text-xs font-semibold">{recipe.timeMinutes}{t.time_min}</span>
              </div>
            </div>
            
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="ghost" size="sm" className="h-8 text-[11px] font-bold text-primary hover:text-primary hover:bg-primary/10 rounded-xl group/btn">
                  {t.recipe_details}
                  <ChevronRight size={14} className="ml-1 transition-transform group-hover/btn:translate-x-0.5" />
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-3xl bg-card border-white/10 overflow-hidden p-0 rounded-3xl">
                <div className="relative h-64 md:h-80 w-full">
                  <img src={recipe.imageUrl} alt={recipe.title} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                  <div className="absolute bottom-6 left-6 right-6">
                    <DialogTitle className="text-3xl md:text-4xl font-display font-bold text-white mb-2">{t[recipe.title] || recipe.title}</DialogTitle>
                    <div className="flex items-center gap-4 text-white/90">
                      <div className="flex items-center gap-1.5">
                        <Clock size={18} className="text-primary" />
                        <span className="text-sm font-medium">{recipe.timeMinutes} {t.time_min}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Flame size={18} className="text-orange-500" />
                        <span className="text-sm font-medium">{recipe.calories} {t.kcal}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Star size={18} className="fill-primary text-primary" />
                        <span className="text-sm font-medium">{recipe.rating}</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="p-6 md:p-8 grid grid-cols-1 md:grid-cols-3 gap-8 max-h-[60vh] overflow-y-auto custom-scrollbar">
                  <div className="md:col-span-1 space-y-6">
                    <div>
                      <h4 className="text-lg font-bold text-foreground mb-3 flex items-center gap-2">
                        <span className="w-1.5 h-6 bg-primary rounded-full" />
                        {t.ingredients}
                      </h4>
                      <div className="space-y-2">
                        {recipe.ingredients?.split('\n').map((ing, i) => (
                          <div key={i} className="flex items-start gap-2 text-muted-foreground text-sm">
                            <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-primary/40 shrink-0" />
                            <span>{ing.replace('• ', '')}</span>
                          </div>
                        )) || "Секретные ингредиенты..."}
                      </div>
                      <Button 
                        onClick={handleAddToList}
                        className="w-full mt-6 rounded-xl bg-primary/10 text-primary hover:bg-primary/20 border-none"
                      >
                        <ShoppingCart className="w-4 h-4 mr-2" />
                        {t.add_to_shopping_list}
                      </Button>
                    </div>
                  </div>
                  <div className="md:col-span-2 space-y-6">
                    <div>
                      <h4 className="text-lg font-bold text-foreground mb-3 flex items-center gap-2">
                        <span className="w-1.5 h-6 bg-primary rounded-full" />
                        {t.instructions}
                      </h4>
                      <div className="space-y-4">
                        {recipe.instructions?.split('\n').map((step, i) => (
                          <div key={i} className="relative pl-10">
                            <span className="absolute left-0 top-0 w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-sm">
                              {i + 1}
                            </span>
                            <p className="text-muted-foreground text-sm leading-relaxed pt-1.5">
                              {step.replace(/^\d+\.\s*/, '')}
                            </p>
                          </div>
                        )) || "Инструкция появится позже."}
                      </div>
                    </div>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
