import { pgTable, text, serial, integer, boolean, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const recipes = pgTable("recipes", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  imageUrl: text("image_url").notNull(),
  timeMinutes: integer("time_minutes").notNull(),
  calories: integer("calories").notNull(),
  rating: numeric("rating", { precision: 2, scale: 1 }).notNull(),
  isFavorite: boolean("is_favorite").default(false),
  ingredients: text("ingredients"),
  instructions: text("instructions"),
  category: text("category").notNull().default('all'),
});

export const recipeSubmissions = pgTable("recipe_submissions", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  ingredients: text("ingredients").notNull(),
  instructions: text("instructions").notNull(),
  submittedAt: text("submitted_at").notNull(),
});

export const insertRecipeSchema = createInsertSchema(recipes).omit({ id: true });
export const insertSubmissionSchema = createInsertSchema(recipeSubmissions).omit({ id: true });
export type InsertRecipe = z.infer<typeof insertRecipeSchema>;
export type InsertSubmission = z.infer<typeof insertSubmissionSchema>;
export type Recipe = typeof recipes.$inferSelect;
export type RecipeSubmission = typeof recipeSubmissions.$inferSelect;

export type UpdateRecipeRequest = Partial<InsertRecipe>;
export type ToggleFavoriteRequest = { isFavorite: boolean };
