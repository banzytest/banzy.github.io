import { z } from 'zod';
import { insertRecipeSchema, recipes } from './schema';

export const errorSchemas = {
  validation: z.object({ message: z.string(), field: z.string().optional() }),
  notFound: z.object({ message: z.string() }),
  internal: z.object({ message: z.string() }),
};

export const api = {
  recipes: {
    list: {
      method: 'GET' as const,
      path: '/api/recipes' as const,
      responses: {
        200: z.array(z.custom<typeof recipes.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/recipes/:id' as const,
      responses: {
        200: z.custom<typeof recipes.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    toggleFavorite: {
      method: 'PATCH' as const,
      path: '/api/recipes/:id/favorite' as const,
      input: z.object({ isFavorite: z.boolean() }),
      responses: {
        200: z.custom<typeof recipes.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    submit: {
      method: 'POST' as const,
      path: '/api/recipe-submissions' as const,
      input: z.object({
        title: z.string(),
        description: z.string(),
        ingredients: z.string(),
        instructions: z.string(),
      }),
      responses: {
        201: z.object({ message: z.string() }),
      },
    },
    scan: {
      method: 'POST' as const,
      path: '/api/scan-ingredients' as const,
      input: z.object({ image: z.string() }),
      responses: {
        200: z.array(z.custom<typeof recipes.$inferSelect>()),
      },
    }
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}

export type RecipeInput = z.infer<typeof insertRecipeSchema>;
export type RecipeResponse = z.infer<typeof api.recipes.get.responses[200]>;
export type RecipesListResponse = z.infer<typeof api.recipes.list.responses[200]>;
