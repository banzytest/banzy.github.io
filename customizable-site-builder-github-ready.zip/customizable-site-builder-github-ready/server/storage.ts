import { db } from "./db";
import { recipes, type InsertRecipe, type Recipe, type ToggleFavoriteRequest } from "@shared/schema";
import { eq } from "drizzle-orm";

export interface IStorage {
  getRecipes(): Promise<Recipe[]>;
  getRecipe(id: number): Promise<Recipe | undefined>;
  createRecipe(recipe: InsertRecipe): Promise<Recipe>;
  toggleFavorite(id: number, updates: ToggleFavoriteRequest): Promise<Recipe>;
}

export class DatabaseStorage implements IStorage {
  async getRecipes(): Promise<Recipe[]> {
    return await db.select().from(recipes);
  }

  async getRecipe(id: number): Promise<Recipe | undefined> {
    const [recipe] = await db.select().from(recipes).where(eq(recipes.id, id));
    return recipe;
  }

  async createRecipe(recipe: InsertRecipe): Promise<Recipe> {
    const [created] = await db.insert(recipes).values(recipe).returning();
    return created;
  }

  async toggleFavorite(id: number, updates: ToggleFavoriteRequest): Promise<Recipe> {
    const [updated] = await db.update(recipes)
      .set({ isFavorite: updates.isFavorite })
      .where(eq(recipes.id, id))
      .returning();
    return updated;
  }
}

export const storage = new DatabaseStorage();
