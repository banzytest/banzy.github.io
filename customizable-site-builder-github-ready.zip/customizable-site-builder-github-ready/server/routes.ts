import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.get(api.recipes.list.path, async (req, res) => {
    const recipes = await storage.getRecipes();
    res.json(recipes);
  });

  app.get(api.recipes.get.path, async (req, res) => {
    const recipe = await storage.getRecipe(Number(req.params.id));
    if (!recipe) {
      return res.status(404).json({ message: "Recipe not found" });
    }
    res.json(recipe);
  });

  app.patch(api.recipes.toggleFavorite.path, async (req, res) => {
    try {
      const input = api.recipes.toggleFavorite.input.parse(req.body);
      const updated = await storage.toggleFavorite(Number(req.params.id), input);
      res.json(updated);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      res.status(404).json({ message: "Recipe not found" });
    }
  });

  app.post(api.recipes.submit.path, async (req, res) => {
    const input = api.recipes.submit.input.parse(req.body);
    console.log("New recipe submission:", input);
    res.status(201).json({ message: "Success" });
  });

  app.post(api.recipes.scan.path, async (req, res) => {
    // Mock scanner logic
    const recipes = await storage.getRecipes();
    res.json(recipes.slice(0, 2));
  });

  // Seed data
  await seedDatabase();

  return httpServer;
}

async function seedDatabase() {
  const existing = await storage.getRecipes();
  if (existing.length === 0) {
    const recipesToSeed = [
      {
        title: "recipe_pancakes_classic",
        description: "Тонкие и нежные блинчики на завтрак",
        imageUrl: "https://images.unsplash.com/photo-1528207776546-365bb710ee93?q=80&w=1000&auto=format&fit=crop",
        timeMinutes: 20,
        calories: 320,
        rating: "4.8",
        isFavorite: false,
        category: "breakfast",
        ingredients: "• яйца\n• молоко\n• мука\n• сахар\n• соль",
        instructions: "1. Смешайте яйца с сахаром и солью.\n2. Добавьте молоко и муку.\n3. Тщательно перемешайте.\n4. Жарьте на разогретой сковороде."
      },
      {
        title: "recipe_scramble_avocado",
        description: "Питательный завтрак для энергичного дня",
        imageUrl: "https://images.unsplash.com/photo-1494597564530-871f2b93ac55?q=80&w=1000&auto=format&fit=crop",
        timeMinutes: 10,
        calories: 350,
        rating: "4.7",
        isFavorite: false,
        category: "breakfast",
        ingredients: "• яйца\n• авокадо\n• хлеб\n• сливочное масло",
        instructions: "1. Взбейте яйца.\n2. Обжарьте на сливочном масле постоянно помешивая.\n3. Подавайте с нарезанным авокадо на тосте."
      },
      {
        title: "recipe_caesar_salad",
        description: "Классический салат с курицей и соусом цезарь",
        imageUrl: "https://images.unsplash.com/photo-1550304943-4f24f54ddde9?q=80&w=1000&auto=format&fit=crop",
        timeMinutes: 25,
        calories: 380,
        rating: "4.9",
        isFavorite: false,
        category: "lunch",
        ingredients: "• курица\n• салат\n• сыр\n• сухарики\n• соус",
        instructions: "1. Обжарьте курицу.\n2. Нарвите салат.\n3. Добавьте сухарики и сыр.\n4. Заправьте соусом."
      },
      {
        title: "recipe_mushroom_soup",
        description: "Нежный грибной суп со сливками",
        imageUrl: "https://images.unsplash.com/photo-1603105037880-880cd4edfb0d?q=80&w=1000&auto=format&fit=crop",
        timeMinutes: 35,
        calories: 280,
        rating: "4.8",
        isFavorite: false,
        category: "lunch",
        ingredients: "• шампиньоны\n• лук\n• сливки\n• картофель",
        instructions: "1. Обжарьте лук и грибы.\n2. Отварите картофель.\n3. Измельчите все блендером.\n4. Добавьте сливки и прогрейте."
      },
      {
        title: "recipe_spaghetti_bolognese",
        description: "Традиционная итальянская паста с мясным соусом",
        imageUrl: "https://images.unsplash.com/photo-1598866539624-99ce57018a4c?q=80&w=1000&auto=format&fit=crop",
        timeMinutes: 40,
        calories: 550,
        rating: "4.9",
        isFavorite: false,
        category: "dinner",
        ingredients: "• спагетти\n• фарш\n• томаты\n• лук\n• чеснок",
        instructions: "1. Отварите спагетти.\n2. Обжарьте лук и чеснок.\n3. Добавьте фарш и томаты.\n4. Тушите 20 минут и смешайте с пастой."
      },
      {
        title: "recipe_baked_salmon",
        description: "Полезный ужин с рыбой и лимоном",
        imageUrl: "https://images.unsplash.com/photo-1467003909585-2f8a72700288?q=80&w=1000&auto=format&fit=crop",
        timeMinutes: 20,
        calories: 420,
        rating: "5.0",
        isFavorite: false,
        category: "dinner",
        ingredients: "• лосось\n• лимон\n• розмарин\n• масло",
        instructions: "1. Сбрызните лосось маслом и лимоном.\n2. Положите веточку розмарина.\n3. Запекайте 15 минут при 200°C."
      },
      {
        title: "recipe_chocolate_mousse",
        description: "Легкий и воздушный десерт",
        imageUrl: "https://images.unsplash.com/photo-1541783245831-57d6fb0926d3?q=80&w=1000&auto=format&fit=crop",
        timeMinutes: 15,
        calories: 250,
        rating: "4.9",
        isFavorite: false,
        category: "desserts",
        ingredients: "• шоколад\n• сливки\n• сахар",
        instructions: "1. Растопите шоколад.\n2. Взбейте сливки с пудрой.\n3. Аккуратно смешайте шоколад со сливками.\n4. Охладите 2 часа."
      },
      {
        title: "recipe_apple_strudel",
        description: "Традиционный десерт с яблоками и корицей",
        imageUrl: "https://images.unsplash.com/photo-1536304993881-ff6e9eefa2a6?q=80&w=1000&auto=format&fit=crop",
        timeMinutes: 50,
        calories: 340,
        rating: "4.7",
        isFavorite: false,
        category: "desserts",
        ingredients: "• тесто\n• яблоки\n• изюм\n• корица",
        instructions: "1. Нарежьте яблоки, смешайте с сахаром и корицей.\n2. Раскатайте тесто.\n3. Выложите начинку и сверните рулет.\n4. Выпекайте 30 минут."
      },
      {
        title: "recipe_guacamole",
        description: "Мексиканская закуска из авокадо",
        imageUrl: "https://images.unsplash.com/photo-1540189549336-e6e99c3679fe?q=80&w=1000&auto=format&fit=crop",
        timeMinutes: 10,
        calories: 180,
        rating: "4.8",
        isFavorite: false,
        category: "snack",
        ingredients: "• авокадо\n• лайм\n• кинза\n• чили",
        instructions: "1. Разомните авокадо вилкой.\n2. Добавьте сок лайма.\n3. Вмешайте мелко нарезанную кинзу и чили."
      },
      {
        title: "recipe_hummus_classic",
        description: "Популярная восточная закуска из нута",
        imageUrl: "https://images.unsplash.com/photo-1541518763669-27fef04b14ea?q=80&w=1000&auto=format&fit=crop",
        timeMinutes: 15,
        calories: 220,
        rating: "4.6",
        isFavorite: false,
        category: "snack",
        ingredients: "• нут\n• тахини\n• масло\n• чеснок\n• лимон",
        instructions: "1. Измельчите нут в блендере.\n2. Добавьте тахини, масло и сок лимона.\n3. Взбейте до однородности."
      },
      {
        title: "recipe_tuna_sandwich",
        description: "Быстрый перекус для любителей рыбы",
        imageUrl: "https://images.unsplash.com/photo-1528735602780-2552fd46c7af?q=80&w=1000&auto=format&fit=crop",
        timeMinutes: 5,
        calories: 310,
        rating: "4.5",
        isFavorite: false,
        category: "snack",
        ingredients: "• хлеб\n• тунец\n• майонез\n• салат",
        instructions: "1. Смешайте тунец с майонезом.\n2. Выложите на хлеб с листьями салата."
      },
      {
        title: "recipe_poached_egg_toast",
        description: "Идеальный завтрак выходного дня",
        imageUrl: "https://images.unsplash.com/photo-1525351484163-7529414344d8?q=80&w=1000&auto=format&fit=crop",
        timeMinutes: 12,
        calories: 280,
        rating: "4.9",
        isFavorite: false,
        category: "breakfast",
        ingredients: "• яйца\n• хлеб\n• авокадо\n• уксус",
        instructions: "1. Сварите яйцо пашот в воде с уксусом.\n2. Подавайте на тосте with авокадо."
      },
      {
        title: "recipe_chicken_teriyaki",
        description: "Азиатский вкус на вашей кухне",
        imageUrl: "https://images.unsplash.com/photo-1598515214211-89d3c73ae83b?q=80&w=1000&auto=format&fit=crop",
        timeMinutes: 25,
        calories: 450,
        rating: "4.8",
        isFavorite: false,
        category: "lunch",
        ingredients: "• курица\n• соус\n• рис\n• кунжут",
        instructions: "1. Обжарьте курицу.\n2. Добавьте соус.\n3. Подавайте с рисом и кунжутом."
      },
      {
        title: "recipe_syrniki_raisins",
        description: "Творожный завтрак родом из детства",
        imageUrl: "https://images.unsplash.com/photo-1626202340534-f347b6a0c502?q=80&w=1000&auto=format&fit=crop",
        timeMinutes: 20,
        calories: 380,
        rating: "4.7",
        isFavorite: false,
        category: "breakfast",
        ingredients: "• творог\n• яйца\n• мука\n• изюм",
        instructions: "1. Смешайте творог, яйцо и муку.\n2. Сформируйте сырники и обжарьте."
      },
      {
        title: "recipe_glass_noodles_veggies",
        description: "Легкий ужин в восточном стиле",
        imageUrl: "https://images.unsplash.com/photo-1512058560366-cd2427ff0601?q=80&w=1000&auto=format&fit=crop",
        timeMinutes: 15,
        calories: 290,
        rating: "4.6",
        isFavorite: false,
        category: "dinner",
        ingredients: "• фунчоза\n• перец\n• огурец\n• соус",
        instructions: "1. Залейте лапшу кипятком.\n2. Нарежьте овощи соломкой.\n3. Смешайте все с соусом."
      },
      {
        title: "recipe_mushroom_julienne",
        description: "Изысканная горячая закуска",
        imageUrl: "https://images.unsplash.com/photo-1511690656952-34342bb7c2f2?q=80&w=1000&auto=format&fit=crop",
        timeMinutes: 30,
        calories: 340,
        rating: "4.8",
        isFavorite: false,
        category: "dinner",
        ingredients: "• шампиньоны\n• сливки\n• сыр\n• лук",
        instructions: "1. Обжарьте грибы с луком.\n2. Залейте сливками и посыпьте сыром.\n3. Запекайте до корочки."
      },
      {
        title: "recipe_pancakes_syrup",
        description: "Пышные американские блинчики",
        imageUrl: "https://images.unsplash.com/photo-1567620905732-2d1ec7bb7445?q=80&w=1000&auto=format&fit=crop",
        timeMinutes: 15,
        calories: 420,
        rating: "4.9",
        isFavorite: false,
        category: "breakfast",
        ingredients: "• мука\n• кефир\n• яйца\n• сироп",
        instructions: "1. Смешайте тесто.\n2. Жарьте небольшие оладьи.\n3. Полейте сиропом."
      },
      {
        title: "recipe_chicken_quesadilla",
        description: "Мексиканское блюдо для всей семьи",
        imageUrl: "https://images.unsplash.com/photo-1599974579688-8dbdd335c77f?q=80&w=1000&auto=format&fit=crop",
        timeMinutes: 20,
        calories: 480,
        rating: "4.7",
        isFavorite: false,
        category: "lunch",
        ingredients: "• тортилья\n• курица\n• сыр\n• кукуруза",
        instructions: "1. Выложите начинку на тортилью.\n2. Сложите и обжарьте до расплавления сыра."
      },
      {
        title: "recipe_walnut_brownie",
        description: "Мега-шоколадный десерт",
        imageUrl: "https://images.unsplash.com/photo-1606313564200-e75d5e30476c?q=80&w=1000&auto=format&fit=crop",
        timeMinutes: 45,
        calories: 520,
        rating: "5.0",
        isFavorite: false,
        category: "desserts",
        ingredients: "• шоколад\n• масло\n• яйца\n• орехи",
        instructions: "1. Растопите шоколад с маслом.\n2. Смешайте с яйцами и орехами.\n3. Выпекайте 25 минут."
      },
      {
        title: "recipe_fruit_sorbet",
        description: "Натуральное лакомство из ягод",
        imageUrl: "https://images.unsplash.com/photo-1497034825429-c343d7c6a68f?q=80&w=1000&auto=format&fit=crop",
        timeMinutes: 10,
        calories: 150,
        rating: "4.8",
        isFavorite: false,
        category: "desserts",
        ingredients: "• ягоды\n• банан\n• йогурт",
        instructions: "1. Взбейте все ингредиенты в блендере.\n2. Подавайте сразу."
      }
    ];

    for (const recipe of recipesToSeed) {
      await storage.createRecipe(recipe);
    }
  }
}
