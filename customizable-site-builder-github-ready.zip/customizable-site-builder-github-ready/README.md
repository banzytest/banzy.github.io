# REST Express

A modern full-stack JavaScript application template with Express backend and React frontend. Built with TypeScript, featuring seamless development workflow, database integration, and production-ready tooling.

## Features

- **Full-Stack TypeScript** - Type-safe code across frontend and backend
- **Express Backend** - Lightweight and flexible server framework
- **React Frontend** - Modern UI with component-based architecture
- **Vite** - Lightning-fast build tool and dev server
- **Database Integration** - PostgreSQL with Drizzle ORM
- **UI Components** - Pre-configured Shadcn components with Tailwind CSS
- **Form Handling** - React Hook Form with Zod validation
- **Data Fetching** - TanStack React Query for state management
- **Responsive Design** - Mobile-first with Tailwind CSS
- **Dark Mode Support** - Built-in theme switching with next-themes

## Tech Stack

### Backend
- **Express** 5.0+ - Web framework
- **Drizzle ORM** - Type-safe database access
- **PostgreSQL** - Database
- **Passport** - Authentication
- **Node.js** - Runtime

### Frontend
- **React** 18+ - UI library
- **TypeScript** - Type safety
- **Vite** - Build tool
- **Tailwind CSS** - Styling
- **Shadcn UI** - Component library
- **React Hook Form** - Form management
- **TanStack Query** - Data fetching
- **Wouter** - Routing

## Getting Started

### Prerequisites
- Node.js 18+ 
- npm or yarn

### Installation

1. Clone the repository
```bash
git clone <repository-url>
cd rest-express
```

2. Install dependencies
```bash
npm install
```

3. Set up environment variables
```bash
cp .env.example .env
```

4. Set up the database
```bash
npm run db:push
```

5. Start the development server
```bash
npm run dev
```

The application will be available at `http://localhost:5173` (frontend) with the backend running on the same port via Vite proxy.

## Available Scripts

- `npm run dev` - Start development server (Express + Vite)
- `npm run build` - Build for production
- `npm start` - Start production server
- `npm run check` - Type check with TypeScript
- `npm run db:push` - Push database schema changes

## Project Structure

```
.
├── client/                 # React frontend
│   ├── src/
│   │   ├── pages/         # Page components
│   │   ├── components/    # Reusable components
│   │   ├── hooks/         # Custom React hooks
│   │   ├── lib/           # Utilities and helpers
│   │   └── App.tsx        # Main app component
│   └── index.html         # HTML entry point
├── server/                # Express backend
│   ├── index.ts           # Server entry point
│   ├── routes.ts          # API routes
│   ├── storage.ts         # Database interface
│   └── static.ts          # Static file serving
├── shared/                # Shared code
│   ├── schema.ts          # Data models and validation
│   └── routes.ts          # Shared route definitions
├── script/                # Build scripts
├── tailwind.config.ts     # Tailwind CSS configuration
├── vite.config.ts         # Vite configuration
├── tsconfig.json          # TypeScript configuration
└── drizzle.config.ts      # Drizzle ORM configuration
```

## Development Workflow

### Creating a New Page
1. Add a new file in `client/src/pages/`
2. Register the page in `client/src/App.tsx`
3. Use the `Link` component from Wouter for navigation

### Adding Database Models
1. Define your schema in `shared/schema.ts`
2. Create insert/select types using Drizzle-Zod
3. Update storage interface in `server/storage.ts`
4. Implement CRUD routes in `server/routes.ts`

### Creating API Endpoints
1. Define request/response types in shared schema
2. Implement storage methods using your database
3. Add route handlers in `server/routes.ts`
4. Use the query client on frontend to fetch data

### Styling Components
- Use Tailwind CSS utility classes
- Follow dark mode patterns with `dark:` prefix
- Use Shadcn components for consistent design
- Define custom colors in `index.css` CSS variables

## Database

This project uses PostgreSQL with Drizzle ORM. Database schema is version-controlled in the codebase.

### Running Migrations
```bash
npm run db:push
```

### Accessing Database
Database connection is configured through environment variables. Set `DATABASE_URL` in your `.env` file.

## Environment Variables

See `.env.example` for all available configuration options:
- `DATABASE_URL` - PostgreSQL connection string
- `NODE_ENV` - Environment mode (development/production)
- Additional variables as needed for your application

## Building for Production

```bash
npm run build
npm start
```

The build process:
1. Compiles TypeScript backend and frontend
2. Bundles frontend with Vite
3. Creates optimized production bundles
4. Outputs to `dist/` directory

## Contributing

1. Create a feature branch (`git checkout -b feature/amazing-feature`)
2. Commit your changes (`git commit -m 'Add amazing feature'`)
3. Push to the branch (`git push origin feature/amazing-feature`)
4. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

For issues and questions, please use the [GitHub Issues](https://github.com/your-username/rest-express/issues) page.

## Acknowledgments

- Built with [Shadcn UI](https://ui.shadcn.com/)
- Styled with [Tailwind CSS](https://tailwindcss.com/)
- API built with [Express](https://expressjs.com/)
- Database via [Drizzle ORM](https://orm.drizzle.team/)
